# -*- coding: utf-8 -*-
# Copyright 2017 InfoTerra (<http://www.infoterra.hr>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
